class MyRoutes {
  static String get_startedRoute = "/get_started";
  static String LoginPageRoute ="LoginPage";
  static String ForgotPassRoute="ForgotPass";
  static String ChangePassRoute="ChangePass";
  static String OtpPageRoute="/OtpPage";
   static String HomePageRoute="/HomePage";

}