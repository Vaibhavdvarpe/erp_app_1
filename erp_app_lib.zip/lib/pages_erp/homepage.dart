import 'package:erp_app/bloc/user_logout_bloc/user_logout_bloc.dart';
import 'package:erp_app/utils/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? token='';
  String? resultMessage='';
  String? successStatus='';
  String? success ='';

  @override
  Widget build(BuildContext context) {
    var box=GetStorage();
    token=box.read('token');
        print(box.read('token'));
        // logoutBloc.sinkData;
    
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color.fromRGBO(35, 133, 59, 1),
        title: Center(child: Text("Home Screen")),
        
      ),
      body: StreamBuilder(
        stream: logoutBloc.streamData(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
                // token=box.read('token');
                success=snapshot.hasData.toString();
                print(success);

          return Center(
            child: ElevatedButton(   
                    onPressed:()=>{
                      (logoutBloc.sinkData(token)),Navigator.pop(context,MyRoutes.LoginPageRoute)
                    },
                    style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Color.fromRGBO(35, 133, 59, 1))),
                     child: const Text("LogOut"))
          
            );
        }
      )
      
        
      );
  }
}